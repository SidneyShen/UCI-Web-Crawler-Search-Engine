// The name is not quite proper...
import java.util.*;

public class SearchResult
{
	public String url;
	public int docid;
	public double score;
	public String textFragment;
	public String title;
};